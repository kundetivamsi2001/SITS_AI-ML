import streamlit as st
import pickle
import numpy as np

# Page Config
st.set_page_config(page_title="Diabetes Predictor", page_icon="🩺")

# Load model and scaler
model = pickle.load(open("model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

# ----- Title -----
st.markdown(
    "<h1 style='text-align: center; color: #ff4b4b;'>🩺 Diabetes Prediction App</h1>",
    unsafe_allow_html=True
)

st.markdown(
    "<h4 style='text-align: center; color: #4CAF50;'>Enter patient details below</h4>",
    unsafe_allow_html=True
)

# ----- Image -----
st.image(
    "https://img.freepik.com/free-vector/diabetes-concept-illustration_114360-8373.jpg",
    caption="Health Check",
    use_column_width=True
)

# ----- Sidebar -----
st.sidebar.header("About")
st.sidebar.write("Simple ML App using Logistic Regression")
st.sidebar.write("Made with ❤️ using Streamlit")

# ----- Input Form -----
col1, col2 = st.columns(2)

with col1:
    pregnancies = st.number_input("Pregnancies", 0, 20)
    glucose = st.number_input("Glucose", 0, 300)
    blood_pressure = st.number_input("Blood Pressure", 0, 200)
    skin_thickness = st.number_input("Skin Thickness", 0, 100)

with col2:
    insulin = st.number_input("Insulin", 0, 900)
    bmi = st.number_input("BMI", 0.0, 70.0)
    dpf = st.number_input("Diabetes Pedigree Function", 0.0, 3.0)
    age = st.number_input("Age", 0, 120)

st.write("")

# ----- Predict Button -----
if st.button("🔍 Predict Now"):

    input_data = np.array([[pregnancies, glucose, blood_pressure,
                            skin_thickness, insulin, bmi, dpf, age]])

    input_scaled = scaler.transform(input_data)

    prediction = model.predict(input_scaled)

    if prediction[0] == 0:
        st.success("✅ No Diabetes Detected")
    else:
        st.error("⚠️ High Chance of Diabetes")
